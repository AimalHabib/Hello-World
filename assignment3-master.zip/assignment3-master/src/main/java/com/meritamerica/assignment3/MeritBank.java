package com.meritamerica.assignment3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;

public class MeritBank {
	
	private static AccountHolder AccountHolders[] = new AccountHolder[0];
	private static CDOffering CDOfferings[] = new CDOffering[0];
	private static Long nextAccountNumber;
	
	/**
	 * 
	 * @param accountNum the id for account
	 */
	public static void setNextAccountNumber(Long accountNum) {
		MeritBank.nextAccountNumber = accountNum;
	}
	
/**
 * 
 * @param accountHolder to be added to MeritBank
 */
	public static void addAccountHolder(AccountHolder accountHolder) {
		AccountHolder[] copy = Arrays.copyOf(AccountHolders, AccountHolders.length+1);
		AccountHolders = copy;
		AccountHolders[AccountHolders.length-1] = accountHolder;
	}

/**
 * 
 * @return the AccountHolders in MeritBank
 */
	public static AccountHolder[] getAccountHolders() {
		return AccountHolders;
	}

/**
 * 
 * @return the currently available CDOfferings
 */
	public static CDOffering[] getCDOfferings() {
		return CDOfferings;
	}
	
/**
 * 
 * @param depositAmount amount to be tested against the available CDOfferings
 * @return the CDOffering with the best return for depositAmount
 */
	public static CDOffering getBestCDOffering(double depositAmount) {
		double best = 0.0; 
		CDOffering bestOffering = null;
		if(CDOfferings == null) {
			return null;
		}
		for(CDOffering offering :  CDOfferings) {
			if(futureValue(depositAmount, offering.getInterestRate(),
					offering.getTerm()) > best) {
				bestOffering = offering;
				best = futureValue(depositAmount, offering.getInterestRate(),
						offering.getTerm());
			}
		}
		return bestOffering;
	}

/**
 * 
 * @param depositAmount  amount to be tested against the available CDOfferings
 * @return the second best CDOffering
 */
	public static CDOffering getSecondBestCDOffering(double depositAmount) {
		if(CDOfferings == null) {
			return null;
		}
		CDOffering bestOffering = null;
		double best = 0.0; 
		CDOffering secondBestOffering = null;
		
		for(CDOffering offering :  CDOfferings) {
			if(futureValue(depositAmount, offering.getInterestRate(),
					offering.getTerm()) > best) {
				secondBestOffering = bestOffering;
				bestOffering = offering;
				best = futureValue(depositAmount, offering.getInterestRate(),
						offering.getTerm());
			}
		}
		return secondBestOffering;
	}

/**
 * 
 * clears the current CDOfferings
 */
	public static void clearCDOfferings() {
		CDOfferings = null;
	}
	
/**
 * 
 * @param offerings stores the current available CDOfferings
 */
	public static void setCDOfferings(CDOffering[] offerings) {
		CDOfferings = offerings;
	}

/**
 * 
 * @return the next accountNumber to be assigned to Checking/Saving/CDAccounts
 */
	public static long getNextAccountNumber() {
		return nextAccountNumber;
	}

/**
 * 
 * @return the combined balances of all AccountHolders in the bank
 */
	public static double totalBalances() {
		double total = 0.0;
		for(AccountHolder accounts : AccountHolders) {
			total += accounts.getCombinedBalance();
		}
		return total;
		
	}

/**
 * 
 * @param presentValue  presentValue of the amount we are calculating futureValue of
 * @param interestRate  interestRate we are compounding the presentValue by
 * @param term  number of years into the future we are calculating futureValue
 * 
 * @return futureValue of balance given interest rate and term
 */
	public static double futureValue(double presentValue, double interestRate, int term) {
		return presentValue*Math.pow(1 + interestRate,  term);
	}

	public static boolean readFromFile(String fileName) {
		CDOfferings = new CDOffering[0];
		setNextAccountNumber((long) 0);
		AccountHolders = new AccountHolder[0];
		try {
			FileReader reader = new FileReader(fileName);
			BufferedReader nextLine = new BufferedReader(reader);
			setNextAccountNumber(Long.valueOf(nextLine.readLine()));
			int numOfCDO = Integer.valueOf(nextLine.readLine());
			for(int i=0; i<numOfCDO;i++) {
				CDOfferings = Arrays.copyOf(CDOfferings, CDOfferings.length+1);
				CDOfferings[CDOfferings.length-1]=CDOffering.readFromString(nextLine.readLine());
			}
			int numOfAccountHolders = Integer.valueOf(nextLine.readLine());
			for(int b =0;b<numOfAccountHolders;b++) {
				AccountHolder nextAccountHolder = AccountHolder.readFromString(nextLine.readLine());
				int numOfCheckingAccount = Integer.valueOf(nextLine.readLine());
				for(int a=0;a<numOfCheckingAccount;a++) {
					nextAccountHolder.addCheckingAccount(CheckingAccount.readFromString(nextLine.readLine()));
				}
				int numOfSavingAccount = Integer.valueOf(nextLine.readLine());
				for(int a=0;a<numOfSavingAccount;a++) {
					nextAccountHolder.addSavingsAccount(SavingsAccount.readFromString(nextLine.readLine()));
				}
				int numOfsavingAccount = Integer.valueOf(nextLine.readLine());
				for(int a=0;a<numOfsavingAccount;a++) {
					nextAccountHolder.addCDAccount(CDAccount.readFromString(nextLine.readLine()));
				}
				MeritBank.addAccountHolder(nextAccountHolder);
			} 
			reader.close();
			return true;
		}catch(Exception e) {
			return false;
		}
	}
	
	/**
	 * 
	 * @return returns the sorted accounts in an ascended order
	 */
	public static AccountHolder[] sortAccountHolders() {
		Arrays.sort(AccountHolders);
		
		return AccountHolders;
	}
}
