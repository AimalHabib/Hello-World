package com.meritamerica.assignment6.models;

public class ExceedsCombinedBalanceLimitException extends Exception {
	public ExceedsCombinedBalanceLimitException() {
        super("ExceedsCombinedBalanceLimitException");
    }
}
