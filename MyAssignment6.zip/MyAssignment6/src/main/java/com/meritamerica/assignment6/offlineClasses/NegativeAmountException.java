package com.meritamerica.assignment6.offlineClasses;

public class NegativeAmountException extends Exception {
	public NegativeAmountException() {
        super("NegativeAmountException");
    }
}
