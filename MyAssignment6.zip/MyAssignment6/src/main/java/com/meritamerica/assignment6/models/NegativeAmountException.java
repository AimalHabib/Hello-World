package com.meritamerica.assignment6.models;

public class NegativeAmountException extends Exception {
	public NegativeAmountException() {
        super("NegativeAmountException");
    }
}
