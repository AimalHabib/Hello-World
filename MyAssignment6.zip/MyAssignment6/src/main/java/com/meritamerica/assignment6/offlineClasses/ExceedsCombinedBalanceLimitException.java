package com.meritamerica.assignment6.offlineClasses;

public class ExceedsCombinedBalanceLimitException extends Exception {
	public ExceedsCombinedBalanceLimitException() {
        super("ExceedsCombinedBalanceLimitException");
    }
}
