package com.meritamerica.assignment6.models;

public class ExceedsFraudSuspicionLimitException extends Exception {
	
	public ExceedsFraudSuspicionLimitException() {
        super("ExceedsFraudSuspicionLimitException");
    }
}
