package com.meritamerica.assignment6.offlineClasses;

public class ExceedsAvailableBalanceException extends Exception {
	public ExceedsAvailableBalanceException() {
        super("ExceedsAvailableBalanceException");
    }
}
