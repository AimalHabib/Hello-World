
public class CoffeeTouchscreenAdapter extends OldCoffeeMachine implements CoffeeMachineInterface{

	public static void main(String[] args) {
		CoffeeTouchscreenAdapter adapter = new CoffeeTouchscreenAdapter();
		adapter.chooseFirstSelection();
		adapter.chooseSecondSelection();
	}
	@Override
	public void chooseFirstSelection() {
		OldCoffeeMachine old = new OldCoffeeMachine();
		old.SelectA();
	}

	@Override
	public void chooseSecondSelection() {
		OldCoffeeMachine old = new OldCoffeeMachine();
		old.SelectA();
	}

}
