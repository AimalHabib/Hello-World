
public interface CoffeeMachineInterface{
	void chooseFirstSelection();
	void chooseSecondSelection();
}
