
public class OldCoffeeMachine{
	public void SelectA() {
		System.out.println("Selected Option A");
	}
	public void SelectB() {
		System.out.println("Selected Option B");
	}
}
