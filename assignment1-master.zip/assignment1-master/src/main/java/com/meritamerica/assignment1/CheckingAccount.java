package com.meritamerica.assignment1;

public class CheckingAccount {
	
	private double balance;
	
	private final double INTEREST_RATE = 0.0001;
	
/**
 * 
 * Main constructor for CheckingAccount
 * 
 * @param openingBalance stores balance into this CheckingAccount
 */
	public CheckingAccount(double openingBalance){
		this.balance = openingBalance;
	}
	
/**
 * 	
 * @return balance from this CheckingAccount
 */
	public double getBalance() {
		return balance;
	}
	
/**
 * 	
 * @return INTEREST_RATE for CheckingAccounts
 */
	public double getInterestRate() {
		return INTEREST_RATE;
	}
	
/**
 * 	
 * @param amount  amount to withdraw from this CheckingAccount
 * @return true if there is enough money and not a negative number
 */
	public boolean withdraw(double amount) {
		if(amount <= balance && amount > 0) {
			this.balance = balance - amount;
			System.out.println("Withdrawn " + amount);
			System.out.println(balance);
			return true;
		}
		return false;
	}
	
/**
 * 
 * @param amount  to deposit into the CheckingAccount
 * @return true if amount is greater than 0
 */
	public boolean deposit(double amount) {
		if (amount > 0) {
			this.balance = balance + amount;
			return true;
		}
		return false;		
	}
	
/**
 * 	
 * @param years  how many years of interest to calculate
 * @return balance after x years interest
 */
	public double futureValue(int years) {
		return balance*Math.pow(1 + INTEREST_RATE, years);
	}
	
/**
 * 
 * @return String containing details of this CheckingAccount	
 */
	public String toString() {
		String toString = 
		"Checking Account Balance: $" + getBalance() + "\n" + 
		"Checking Account Interest Rate: " + INTEREST_RATE + "\n" + 
		"Checking Account Balance in 3 years: $" + futureValue(3);
		return toString;
	}
}