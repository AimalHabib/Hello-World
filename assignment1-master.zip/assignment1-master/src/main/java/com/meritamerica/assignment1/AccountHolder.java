package com.meritamerica.assignment1;

public class AccountHolder {
	
	private String firstName;
	private String middleName;
	private String lastName;
	private String ssn;
	CheckingAccount checking;
	SavingsAccount savings;
/*
 * Default constructor for AccountHolder Class.
 */	
	public AccountHolder() {
		this.firstName = "";
		this.middleName = "";
		this.lastName = "";
		this.ssn = "";
		checking = new CheckingAccount(0.0);
		savings = new SavingsAccount(0.0);	
	}
/**
 * 
 * Main constructor for AccountHolder.
 * 
 * @param firstName  Storing first name
 * @param middleName  Storing middle name
 * @param lastName Storing last name
 * @param ssn Storing social security number
 * @param checkingAccountOpeningBalance Stores double into CheckingAccount object
 * @param savingsAccountOpeningBalance Stores double into SavingsAccount object
 */
	public AccountHolder(String firstName, String middleName, String lastName,
			String ssn, double checkingAccountOpeningBalance, double savingsAccountOpeningBalance){
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.ssn = ssn;
		checking = new CheckingAccount(checkingAccountOpeningBalance);
		savings = new SavingsAccount(savingsAccountOpeningBalance);
	}
	
/**
 * 
 * @return the firstName of this AccountHolder
 */
	public String getFirstName() {
		return firstName;
	}
	
/**
 *
 * @param firstName  Stores firstName of this AccountHolder
 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
/**
 * 
 * @return the middleName of this AccountHolder
 */
	public String getMiddleName() {
		return middleName;
	}
	
/**
 * 
 * @param middleName  store middleName of this AccountHolder
 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	
/**
 * 
 * @return lastName of this AccountHolder
 */
	public String getLastName() {
		return lastName;
	}
	
/**
 * 
 * @param lastName  stares middleName of this AccountHolder
 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
/**
 * 
 * @return social security number of this AccountHolder
 */
	public String getSsn() {
		return ssn;
	}
	
/**
 * 
 * @param ssn  Stores social security number of this AccountHolder
 */
	public void setSsn(String ssn) {
		this.ssn = ssn;
	}
	
/**
 * 
 * @return checking object of this CheckingAccount for this AccountHolder
 */
	public CheckingAccount getCheckingAccount() {		
		return checking;
	}
	
/**
 * 
 * @return savings object for this SavingsAccount for this AccountHolder
 */
	public SavingsAccount getSavingsAccount() {		 
		return savings;
	}
	
/**
 * 
 * @return string for details of this AccountHolder
 */
	public String toString() {
		String toString = 
				"Name : " + firstName + " " + middleName + " " + lastName + "\n" +
				"SSN: " + ssn + "\n" + 
				getCheckingAccount().toString() + "\n" +
				getSavingsAccount().toString();		
		return toString;
	}
}