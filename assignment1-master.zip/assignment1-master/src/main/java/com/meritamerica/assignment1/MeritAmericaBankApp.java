package com.meritamerica.assignment1;

/**
 * 
* Main for MaritAmericaBankApp with various test cases.
* 
*
*
* @version 1.0
* @since   2020/02/27
*/

public class MeritAmericaBankApp {
	public static void main(String[] args) {
		
		AccountHolder josh = new AccountHolder(
				"Joshua","James","Freeman","123456789",100,1000);

		System.out.println(josh.toString());
		josh.getCheckingAccount().deposit(500);
		josh.getSavingsAccount().withdraw(800);
		System.out.println(josh.getCheckingAccount().toString());
		System.out.println(josh.getSavingsAccount().toString());

		AccountHolder john = new AccountHolder(
				"John","James","Doe","987654321",200,500);
		john.getCheckingAccount().deposit(-500);
		john.getSavingsAccount().withdraw(600);
		System.out.println(john.toString());
	}
	
}