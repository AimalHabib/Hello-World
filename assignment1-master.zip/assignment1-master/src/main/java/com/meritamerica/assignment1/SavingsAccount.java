package com.meritamerica.assignment1;

public class SavingsAccount {
	
	private double balance;
	private final double INTEREST_RATE = 0.01;
	
/**
 * 
 * Main constructor for SavingsAccount object for AccountHolder
 * 	
 * @param openingBalance balance to store in this SavingsAccount
 */
	public SavingsAccount(double openingBalance){
		this.balance = openingBalance;
	}
	
/**
 * 	
 * @return balance for this SavingsAccount
 */
	public double getBalance() {
		return balance;
	}
	
/**
 * 	
 * @return INTEREST_RATE for SavingsAccount
 */	
	public double getInterestRate() {
		return INTEREST_RATE;
	}
	
/**
 * 	
 * @param amount  amount to withdraw from this SavingsAccount
 * @return true if amount is more than balance and not a negative number
 */	
	public boolean withdraw(double amount) {
		if(amount <= balance && amount > 0) {
			this.balance = balance - amount;
			return true;
		}
		return false;
	}
	
/**
 * 	
 * @param amount  to deposit into this SavingsAccount
 * @return true if amount is not a negative number
 */
	public boolean deposit(double amount) {
		if (amount > 0) {
			this.balance = balance + amount;
			return true;
		}
		return false;	
	}
	
/**
 * 	
 * @param years  how many years of interest 
 * @return balance after x years of interest
 */
	public double futureValue(int years) {
		return balance*Math.pow(1 + INTEREST_RATE, years);
	}
	
/**
 * 
 * @return String of details for this SavingsAcccount	
 */
	public String toString() {
		String toString = 
		"Savings Account Balance: $" + balance + "\n" + 
		"Savings Account Interest Rate: " + INTEREST_RATE + "\n" + 
		"Savings Account Balance in 3 years: $" + futureValue(3);
		return toString;
	}
}