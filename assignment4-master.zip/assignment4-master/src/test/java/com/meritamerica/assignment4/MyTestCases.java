package com.meritamerica.assignment4;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyTestCases {

	@Test
	public void testWithdraw() {
		BankAccount targetAccount = new CheckingAccount(500, 0.001);
		assertEquals(true, targetAccount.withdraw(100.0));
		assertEquals(false, targetAccount.withdraw(10000.0));
	}
	@Test
	public void testDeposit() {
		BankAccount targetAccount = new CheckingAccount(500, 0.001);
		assertEquals(true, targetAccount.deposit(100.0));
		assertEquals(false, targetAccount.deposit(10000.0));
	}
	@Test
	public void testTransfer() {
		BankAccount sourceAccount = new CheckingAccount(500);
		BankAccount targetAccount = new CheckingAccount(100);
		TransferTransaction transaction = new TransferTransaction(sourceAccount, targetAccount, 50);
		assertNotNull(targetAccount.getTransactions());
	}
}
