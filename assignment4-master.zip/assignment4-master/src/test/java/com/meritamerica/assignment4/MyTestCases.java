package com.meritamerica.assignment4;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyTestCases {

	@Test
	public void testWithdraw() {
		BankAccount tAccount = new CheckingAccount(500, 0.001);
		assertEquals(true, tAccount.withdraw(100.0));
		assertEquals(false, tAccount.withdraw(10000.0));
		
		BankAccount sourceAccount = new CheckingAccount(500);
		double amount = 500;
		Transaction transaction = new WithdrawTransaction(sourceAccount, amount);
		FraudQueue.transactionQueue.add(transaction);
		assertNotNull(FraudQueue.transactionQueue.size());
		
		
	}
	@Test
	public void testDeposit() {
		BankAccount targetAccount = new CheckingAccount(500, 0.001);
		assertEquals(true, targetAccount.deposit(100.0));
		assertEquals(false, targetAccount.deposit(10000.0));
		
		BankAccount sourceAccount = new CheckingAccount(500);
		double amount = 500;
		Transaction transaction = new DepositTransaction(sourceAccount, amount);
		FraudQueue.transactionQueue.add(transaction);
		assertNotNull(FraudQueue.transactionQueue.size());
	}
	@Test
	public void testTransfer() {
		BankAccount sourceAccount = new CheckingAccount(500);
		BankAccount targetAccount = new CheckingAccount(100);
		double amount = 500;
		Transaction transaction = new TransferTransaction(sourceAccount, targetAccount, amount);
		FraudQueue.transactionQueue.add(transaction);
		assertNotNull(FraudQueue.transactionQueue.size());
	}
}
