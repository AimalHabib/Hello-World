package com.meritamerica.assignment4;

public class DepositTransaction extends Transaction{
	
	BankAccount targetAccount;
	double amount;
	DepositTransaction(BankAccount targetAccount, double amount){
		this.targetAccount = targetAccount;
		this.amount = amount;
	}
}
