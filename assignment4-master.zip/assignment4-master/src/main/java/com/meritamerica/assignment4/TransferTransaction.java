package com.meritamerica.assignment4;

public class TransferTransaction extends Transaction{
	
	BankAccount targetAccount;
	BankAccount sourceAccount;
	double amount;
	TransferTransaction(BankAccount sourceAccount, BankAccount targetAccount, double amount){
		this.targetAccount=targetAccount;
		this.sourceAccount=sourceAccount;
		this.amount = amount;
	}
}
