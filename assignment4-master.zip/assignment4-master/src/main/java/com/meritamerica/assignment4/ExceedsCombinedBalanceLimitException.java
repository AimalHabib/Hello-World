package com.meritamerica.assignment4;

public class ExceedsCombinedBalanceLimitException extends Exception {
	public ExceedsCombinedBalanceLimitException() {
        super("ExceedsCombinedBalanceLimitException");
    }
}
