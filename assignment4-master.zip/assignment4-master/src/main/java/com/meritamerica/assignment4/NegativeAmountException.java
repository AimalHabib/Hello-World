package com.meritamerica.assignment4;

public class NegativeAmountException extends Exception {

}
