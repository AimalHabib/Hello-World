package com.meritamerica.assignment4;

import java.util.Date;

public abstract class Transaction {
	BankAccount account;
	double amount;
	Date date;
	
	public BankAccount getSourceAccount() {
		return account;
	}
	public void setSourceAccount(){}
	public BankAccount getTargetAccount(){
		return account;}
	public void setTargetAccount(){}
	public double getAmount(){
		return amount;
	}
	public void setAmount(double amount){
		this.amount = amount;
	}
	public java.util.Date getTransactionDate(){
		return date;
	}
	public void setTransactionDate(java.util.Date date){}
	public String writeToString(){
		String string = "To be updated";
		return string;
	}
	public static Transaction readFromString(String transactionDataString){
		return null;
	}

}
