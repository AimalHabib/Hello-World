package com.meritamerica.assignment4;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public abstract class Transaction {
	BankAccount sourceAccount;
	BankAccount targetAccount;
	double amount;
	Date date;
	
	public BankAccount getSourceAccount() {
		return sourceAccount;
	}
	public void setSourceAccount(BankAccount sAccunt){
		this.sourceAccount = sAccunt;
	}
	public BankAccount getTargetAccount(){
		return targetAccount;}
	public void setTargetAccount(BankAccount tAccount){
		this.targetAccount = tAccount;
	}
	public double getAmount(){
		return amount;
	}
	public void setAmount(double amount){
		this.amount = amount;
	}
	public java.util.Date getTransactionDate(){
		return date;
	}
	public void setTransactionDate(java.util.Date date){
		this.date = date;
	}
	public String writeToString(){
		String data = getSourceAccount().getAccountNumber()+","+getTargetAccount().getAccountNumber()+","+getAmount()+","+getTransactionDate();
		return data;
	}
	public static Transaction readFromString(String transactionDataString) throws NumberFormatException{
		//2,4,5000,01/05/2020
		try {
			String[] temp = transactionDataString.split(",");
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(temp[3]);
			
			Transaction trans = new Transaction() { 
	        }; 
	        
	        Long sA = Long.parseLong(temp[0]);
	        BankAccount sAccount = MeritBank.getBankAccount(sA);
	        trans.setSourceAccount(sAccount);
	        Long tA = Long.parseLong(temp[1]);
	        BankAccount tAccount = MeritBank.getBankAccount(tA);
	        trans.setTargetAccount(tAccount);
	        Double amount = Double.parseDouble(temp[2]);
	        trans.setAmount(amount);
	        trans.setTransactionDate(date);
	        return trans;
		} catch (Exception e) {
			throw new NumberFormatException();
		}
	}
}
