package com.meritamerica.assignment4;

import java.util.Date;

public class CheckingAccount extends BankAccount{
	
	/**
	 * 
	 * @param balance the current balance
	 */
	CheckingAccount(double balance) {
		super(balance);
		// TODO Auto-generated constructor stub
		this.balance = balance;
		this.INTEREST_RATE = 0.0001;
	}
	/**
	 * 
	 * @return String containing details of this CheckingAccount	
	 */
	public String toString() {
		String toString = 
		"Checking Account Balance: $" + getBalance() + "\n" + 
		"Checking Account Interest Rate: " + INTEREST_RATE + "\n" + 
		"Checking Account Balance in 3 years: $" + futureValue(3);
		return toString;
	}
	
	/**
	 * 
	 * @param accountData refers to save data on text file
	 * @return returns the updated class
	 */
	public static CheckingAccount readFromString(String accountData) {
		CheckingAccount newAccount = new CheckingAccount(Double.parseDouble(accountData.split(",")[1]));
		//83
		newAccount.setAccountNumber(Long.parseLong(accountData.split(",")[0]));
		//10000
		//0.02
		newAccount.setINTEREST_RATE(Double.parseDouble(accountData.split(",")[2]));
		//01/02/2020
		String dateString = accountData.split(",")[3];
		@SuppressWarnings("deprecation")
		Date date = new Date(dateString);
		
		newAccount.setDate(date);
		return newAccount;
	}
}