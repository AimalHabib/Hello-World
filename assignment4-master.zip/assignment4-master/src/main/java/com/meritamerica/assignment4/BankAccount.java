package com.meritamerica.assignment4;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public abstract class BankAccount {

	long accountNumber = 0;
	double balance = 0;
	double INTEREST_RATE;

	Date date;
	CDOffering cdOffering;
	List<Transaction> transactions = new ArrayList<Transaction>();
	/**
	 * 
	 * @param accountNumber account ID
	 */
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * 
	 * @param balance update balance upon deposit
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	/**
	 * 
	 * @param iNTEREST_RATE the rate of interest
	 */
	public void setINTEREST_RATE(double iNTEREST_RATE) {
		INTEREST_RATE = iNTEREST_RATE;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	/**
	 * 
	 * @param balance the balance on the account
	 */
	BankAccount(double balance){
		this.balance = balance;
	}
	/**
	 * 
	 * @param balancE account balance
	 * @param interestRate account interest rate
	 */
	BankAccount(double balancE, double interestRate){
		this.balance = balancE;
		this.INTEREST_RATE = interestRate;
	}
	/**
	 * 
	 * @param cd CDOffering
	 * @param balance balance of the cdOffering
	 */
	BankAccount(CDOffering cd, double balance){
		this.balance = balance;
		this.cdOffering = cd;
	}
	/**
	 * 
	 * @param balance account balance
	 * @param interestRate account interest rate
	 * @param accountOpenedOn account starting date
	 */
	BankAccount(double balance, double interestRate, java.util.Date accountOpenedOn){}
	/**
	 * 
	 * @param accountNumber account ID
	 * @param balance account balance
	 * @param interestRate interest rate on the account
	 * @param accountOpenedOn date the account opened on
	 */
	BankAccount(long accountNumber, double balance, double interestRate, java.util.Date accountOpenedOn){}
	/**
	 * 
	 * @return the current account number
	 */
	public long getAccountNumber(){
		return accountNumber;}
	/**
	 * 
	 * @return current account balance
	 */
	public double getBalance(){
		return balance;}
	/**
	 * 
	 * @return current interest rate on the account
	 */
	public double getInterestRate(){
		return INTEREST_RATE;}
	/**
	 * 
	 * @return the date the account was created
	 */
	java.util.Date getOpenedOn(){
		return date;
	}
	/**
	 * 	
	 * @param amount  amount to withdraw from this SavingsAccount
	 * @return true if amount is more than balance and not a negative number
	 */	
	public boolean withdraw(double amount) {
		if(amount < balance) {
			balance -= amount;
			return true;
		}

		return false;
	}

	/**
	 * 	
	 * @param amount  to deposit into this SavingsAccount
	 * @return true if amount is not a negative number
	 */
	public boolean deposit(double amount) {
		if(amount > 0) {
			balance+=amount;
			return true;
		}
		return false;	
	}

	/**
	 * 
	 * @param years the number of years
	 * @return
	 */
	public double futureValue(int years){
		return balance*Math.pow(1 + INTEREST_RATE, years); 
	}
	public double futureValueInRecursive(double amount, int years, double IR) {
		if(years <= 1) {
			return 1;
		}else {
			return amount*(1+IR)*futureValueInRecursive(1, years--, IR);
		}
	}

	/**
	 * 
	 * @param accountData refers to save data
	 * @return
	 * @throws ParseException
	 */
	static BankAccount readFromString(String accountData) throws ParseException{
		try {
			String[] temp = accountData.split(",");
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(temp[3]);
			//BankAccount newAccount = new BankAccount(Long.valueOf(temp[0]),
			//Double.valueOf(temp[1]),
			//Double.valueOf(temp[2]),
			//date
			//);
			//return newAccount;
			return null;
		}
		catch(Exception e) {
			throw new NumberFormatException();
		}
	}

	//Should throw a java.lang.NumberFormatException if String cannot be correctly parsed
	String writeToString(){
		return null;}

	public void addTransaction(Transaction transaction){
		transactions.add(transaction);
	}
	public List<Transaction> getTransactions(){
		return transactions;
	}

}
