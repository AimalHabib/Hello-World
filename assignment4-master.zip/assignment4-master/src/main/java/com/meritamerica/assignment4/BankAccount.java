package com.meritamerica.assignment4;

import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public abstract class BankAccount {

	long accountNumber = 0;
	double balance = 0;
	double INTEREST_RATE;

	Date date;
	CDOffering cdOffering;
	List<Transaction> transactions = new ArrayList<Transaction>();
	Set<String> transactionsHistory = new HashSet<String>();
	/**
	 * 
	 * @param accountNumber account ID
	 */
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	/**
	 * 
	 * @param balance update balance upon deposit
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}
	/**
	 * 
	 * @param iNTEREST_RATE the rate of interest
	 */
	public void setINTEREST_RATE(double iNTEREST_RATE) {
		INTEREST_RATE = iNTEREST_RATE;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	/**
	 * 
	 * @param balance the balance on the account
	 */
	BankAccount(double balance){
		this.balance = balance;
	}
	/**
	 * 
	 * @param balancE account balance
	 * @param interestRate account interest rate
	 */
	BankAccount(double balancE, double interestRate){
		this.balance = balancE;
		this.INTEREST_RATE = interestRate;
	}
	/**
	 * 
	 * @param cd CDOffering
	 * @param balance balance of the cdOffering
	 */
	BankAccount(CDOffering cd, double balance){
		this.balance = balance;
		this.cdOffering = cd;
	}
	/**
	 * 
	 * @param balance account balance
	 * @param interestRate account interest rate
	 * @param accountOpenedOn account starting date
	 */
	BankAccount(double balance, double interestRate, java.util.Date accountOpenedOn){}
	/**
	 * 
	 * @param accountNumber account ID
	 * @param balance account balance
	 * @param interestRate interest rate on the account
	 * @param accountOpenedOn date the account opened on
	 */
	BankAccount(long accountNumber, double balance, double interestRate, java.util.Date accountOpenedOn){}
	/**
	 * 
	 * @return the current account number
	 */
	public long getAccountNumber(){
		return accountNumber;}
	/**
	 * 
	 * @return current account balance
	 */
	public double getBalance(){
		return balance;}
	/**
	 * 
	 * @return current interest rate on the account
	 */
	public double getInterestRate(){
		return INTEREST_RATE;}
	/**
	 * 
	 * @return the date the account was created
	 */
	java.util.Date getOpenedOn(){
		return date;
	}
	/**
	 * 	
	 * @param amount  amount to withdraw from this SavingsAccount
	 * @return true if amount is more than balance and not a negative number
	 */	
	public boolean withdraw(double amount) {
		if(amount < balance) {
			balance -= amount;
			return true;
		}

		return false;
	}

	/**
	 * 	
	 * @param amount  to deposit into this SavingsAccount
	 * @return true if amount is not a negative number
	 */
	public boolean deposit(double amount) {
		if(amount > 0 && amount <= 1000) {
			balance+=amount;
			return true;
		}else {
			//Review by fraud team
			return false;
		}	
	}

	/**
	 * 
	 * @param years the number of years
	 * @return
	 */
	public double futureValue(int years){
		return balance*Math.pow(1 + INTEREST_RATE, years); 
	}
	public double futureValueInRecursive(double amount, int years, double IR) {
		if(years <= 1) {
			return 1;
		}else {
			return amount*(1+IR)*futureValueInRecursive(1, years--, IR);
		}
	}

	/**
	 * 
	 * @param accountData refers to save data
	 * @return
	 * @throws ParseException
	 */
	static BankAccount readFromString(String accountData) throws ParseException{
		try {
			String[] temp = accountData.split(",");
			Date date = new SimpleDateFormat("dd/MM/yyyy").parse(temp[3]);
			//BankAccount newAccount = new BankAccount(Long.valueOf(temp[0]),
			//Double.valueOf(temp[1]),
			//Double.valueOf(temp[2]),
			//date
			//);
			//return newAccount;
			return null;
		}
		catch(Exception e) {
			throw new NumberFormatException();
		}
	}

	//Should throw a java.lang.NumberFormatException if String cannot be correctly parsed
	String writeToString() throws java.lang.NumberFormatException{
		try {
			Format f = new SimpleDateFormat("MM/dd/yy");
			String date = f.format(getOpenedOn());
			String data = getAccountNumber()+","+getBalance()+","+getInterestRate()+","+date;
			return data;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}


	public void addTransaction(Transaction transaction){
		transactions.add(transaction);
	}
	public List<Transaction> getTransactions(){
		return transactions;
	}
	public int getTransactionStringSize() {
		return transactionsHistory.size();
		
	}
	public String getTransactionString() {
		ArrayList<String> temp = new ArrayList<>(transactionsHistory);
		String data = "";
		for(int i = 0; i<temp.size(); i++) {
			data += temp.get(i)+"\n";
		}
		return data;
		//return transactionsHistory.toString().replace("[","").replace("]","");
		
	}
	public void addTransactionString(String data) {
		transactionsHistory.add(data);
	}

}
