package com.meritamerica.assignment4;

public class WithdrawTransaction extends Transaction{
	
	BankAccount targetAccount;
	double amount;
	WithdrawTransaction(BankAccount targetAccount, double amount){
		this.targetAccount=targetAccount;
		this.amount = amount;
		if(amount > 1000) {
			//Reviewed by the fraud team
			FraudQueue.addTransaction(this);
		}else {
			//targetAccount.withdraw(amount);
		}
	}
}
