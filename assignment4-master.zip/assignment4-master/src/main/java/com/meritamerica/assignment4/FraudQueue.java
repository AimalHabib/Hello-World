package com.meritamerica.assignment4;

import java.util.LinkedList;
import java.util.Queue;

public class FraudQueue {
	static Queue<Transaction> transactionQueue = new LinkedList<>();
	
	public FraudQueue() {}
	
	public static void addTransaction(Transaction transaction) {
		transactionQueue.add(transaction);		
	}
	public Transaction getTransaction() {
		return (Transaction) transactionQueue;
	}
}
