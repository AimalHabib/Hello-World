package com.meritamerica.assignment4;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

public class FraudQueue {
	static Queue<Transaction> transactionQueue = new LinkedList<>();
	Set<String> fraudHistory = new HashSet<String>();
	public FraudQueue() {}
	
	public int getTransactionNumber() {
		return transactionQueue.size();
	}
	public int getFraudNum() {
		return fraudHistory.size();
	}
	public void addFraudHistory(String data) {
		fraudHistory.add(data);
	}
	public String getTransactionString() {
		ArrayList<String> temp = new ArrayList<>(fraudHistory);
		String data = "";
		for(int i = 0; i<temp.size(); i++) {
			data += temp.get(i)+"\n";
		}
		return data;
	}
	public static void addTransaction(Transaction transaction) {
		transactionQueue.add(transaction);
	}
	public Transaction getTransaction() {
		return (Transaction) transactionQueue;
	}
}
