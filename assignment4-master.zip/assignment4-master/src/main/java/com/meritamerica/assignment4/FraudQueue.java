package com.meritamerica.assignment4;

public class FraudQueue {
	Transaction transaction;
	public FraudQueue() {
	}
	public void addTransaction(Transaction transaction) {}
	public Transaction getTransaction() {
		return transaction;
	}
}
