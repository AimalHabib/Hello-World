package com.meritamerica.assignment6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
