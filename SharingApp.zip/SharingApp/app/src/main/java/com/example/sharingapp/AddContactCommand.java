package com.example.sharingapp;
import android.content.Context;

/**
 * Command to add item
 */
public class AddContactCommand extends Command{

    private ContactList contact_list;
    private Contact contact;
    private Context context;

    public AddContactCommand(ContactList c_list, Contact c, Context context) {
        this.contact_list = c_list;
        this.contact = c;
        this.context = context;
    }

    public void execute(){
        contact_list.addContact(contact);
        setIsExecuted(contact_list.saveContacts(context));
    }
}
