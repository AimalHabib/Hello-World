package com.example.sharingapp;
import android.content.Context;

/**
 * Command to delete an item
 */
public class DeleteContactCommand extends Command {
    private ContactList c_list;
    private Contact c;
    private Context context;

    public DeleteContactCommand(ContactList c_list, Contact c, Context context) {
        this.c_list = c_list;
        this.c = c;
        this.context = context;
    }

    public void execute() {
        c_list.deleteContact(c);
        setIsExecuted(c_list.saveContacts(context));
    }
}
