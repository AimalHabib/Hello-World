package com.example.sharingapp;
import android.content.Context;

/**
 * Command to edit a pre-existing item
 */
public class EditContactCommand extends Command {
    private ContactList c_list;
    private Contact old_c;
    private Contact new_c;
    private Context context;

    public EditContactCommand(ContactList c_list, Contact old_c, Contact new_c, Context context) {
        this.c_list = c_list;
        this.old_c = old_c;
        this.new_c = new_c;
        this.context = context;
    }

    public void execute() {
        c_list.deleteContact(old_c);
        c_list.addContact(new_c);
        setIsExecuted(c_list.saveContacts(context));
    }
}
