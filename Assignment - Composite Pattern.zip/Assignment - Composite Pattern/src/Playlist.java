import java.util.ArrayList;

public class Playlist implements IComponent {

	public String playlistName;
	public ArrayList<IComponent> playlist = new ArrayList<IComponent>();

	public Playlist(String playlistName) {
		this.playlistName = playlistName;
	}

	@Override
	public void play() {
		// TODO Auto-generated method stub
		for(IComponent c : playlist) {
			c.play();
		}
	}

	@Override
	public void setPlaybackSpeed(float speed) {
		// TODO Auto-generated method stub
		for(IComponent c : playlist) {
			c.setPlaybackSpeed(speed);;
		}
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return playlistName;
	}
	
	public boolean add(IComponent component) {
		playlist.add(component);
		return true;
	}

	public boolean remove(IComponent component) {
		playlist.remove(component);
		return true;
	}
}