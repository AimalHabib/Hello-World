import static org.junit.Assert.*;

import org.junit.Test;

public class PlaylistTest {

	@Test
	public void testPlay() {
		Song s = new Song("songName", "artist");
		s.setPlaybackSpeed(3.0f);
		Playlist a = new Playlist("Arrgh");
		a.add(s);
		assertEquals("songName", s.songName);
	}

	@Test
	public void testSetPlaybackSpeed() {
		Song s = new Song("songName", "artist");
		s.setPlaybackSpeed(3.0f);
		Playlist a = new Playlist("Arrgh");
		a.add(s);
		int value = (int)s.getPlaybackSpeed();
		assertSame(3, value);
	}

	@Test
	public void testGetName() {//test playlist name
		Playlist play = new Playlist("Test");
		String test = play.getName();
		assertEquals("Test", test);
	}

	@Test
	public void testAdd() {//test whether the song was added
		Song songComp = new Song("songName", "artist");
		Playlist play = new Playlist("Test");
		boolean addTest = play.add(songComp);
		assertTrue(addTest);
	}

	@Test
	public void testRemove() {//test whether the song was removed
		Song songComp = new Song("songName", "artist");
		Playlist play = new Playlist("Test");
		boolean addTest = play.remove(songComp);
		assertTrue(addTest);
	}

}
