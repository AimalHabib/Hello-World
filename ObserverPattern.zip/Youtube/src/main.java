
public class main {

	public static void main(String[] args) {
		Channel lolChannel = new Channel("LOL", "active");
		Observer a = new Follower("John");
		Observer b = new Follower("Wick");
		Observer c = new Follower("Elezabeth");
		Observer d = new Follower("Shrek");
		Observer e = new Follower("Fin");
		Observer f = new Follower("Crab");
		
		lolChannel.registerObserver(a);
		lolChannel.registerObserver(b);
		lolChannel.registerObserver(c);
		lolChannel.registerObserver(d);
		lolChannel.registerObserver(e);
		lolChannel.registerObserver(f);
		
		lolChannel.notifyObserver();
	}

}
