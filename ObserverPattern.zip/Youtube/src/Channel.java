import java.util.LinkedList;

public class Channel implements Subject{
	LinkedList<Observer> observer = new LinkedList<Observer>();
	public String channelName;
	private String statues;
	
	public Channel(String channelName, String currentStatue) {
		this.channelName = channelName;
		setStatues(currentStatue);
	}
	
	public String getStatues() {
		return statues;
	}

	public void setStatues(String statues) {
		this.statues = statues;
	}

	@Override
	public void registerObserver(Observer obs) {
		observer.add(obs);
		
	}

	@Override
	public void removeObserver(Observer obs) {
		observer.remove(obs);
		
	}

	@Override
	public void notifyObserver() {
		for(Observer elements : observer) {
			elements.update(getStatues());
		}
	}

}
