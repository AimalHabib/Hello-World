
public class Follower implements Observer{

	private String followerName;
	
	public Follower(String followerName) {
		this.followerName = followerName;
	}
	
	public void update(String data) {
		System.out.println("Followe r" + followerName + " is updated");
		
	}
	
	public void play() {
		System.out.println("Playing");
	}
}
