package com.meritamerica.assignment5.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.meritamerica.assignment5.models.AccountHolder;
import com.meritamerica.assignment5.models.CDAccount;
import com.meritamerica.assignment5.models.CDOffering;
import com.meritamerica.assignment5.models.CheckingAccount;
import com.meritamerica.assignment5.models.ExceedsCombinedBalanceLimitException;
import com.meritamerica.assignment5.models.SavingsAccount;

class MeritBankControllerTest {

	@Test
	void testAddAccountHolderFromReq() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		assertEquals(new ResponseEntity<>(tempAcct, HttpStatus.CREATED), tempController.addAccountHolderFromReq(tempAcct));
	}

	@Test
	void testGetAccountHoldersFromReq() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(tempController.aHController, HttpStatus.OK), tempController.getAccountHoldersFromReq());
	}

	@Test
	void testGetAccountHolderByID() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(tempAcct, HttpStatus.OK), tempController.getAccountHolderByID(1));
	}

	@Test
	void testAddCheckingAccountByReq() throws ExceedsCombinedBalanceLimitException {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		CheckingAccount temp = new CheckingAccount(1000.00);
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(temp, HttpStatus.CREATED), tempController.addCheckingAccountByReq(1, temp));
	}

	@Test
	void testGetCheckingAccountsById() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(tempAcct.getCheckingAccounts(), HttpStatus.OK), tempController.getCheckingAccountsById(1));
	}

	@Test
	void testAddSavingsAccountByReq() throws ExceedsCombinedBalanceLimitException {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		SavingsAccount temp = new SavingsAccount(1000.00);
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(temp, HttpStatus.CREATED), tempController.addSavingsAccountByReq(1, temp));
	}

	@Test
	void testGetSavingsAccountsById() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(tempAcct.getSavingsAccounts(), HttpStatus.OK), tempController.getSavingsAccountsById(1));
	}

	@Test
	void testAddCDAccountByReq() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		CDOffering tempOffer = new CDOffering(0,0);
		CDAccount temp = new CDAccount(tempOffer, 1000.00);
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(temp, HttpStatus.CREATED), tempController.addCDAccountByReq(1, temp));
	}

	@Test
	void testGetCDAccountByReq() {
		MeritBankController tempController = new MeritBankController();
		AccountHolder tempAcct = new AccountHolder("f", "m", "l", "123456789");
		tempController.aHController.add(tempAcct);
		assertEquals(new ResponseEntity<>(tempAcct.getCDAccounts(), HttpStatus.OK), tempController.getCDAccountByReq(1));
	}

	@Test
	void testAddCDOfferingByReq() {
		MeritBankController tempController = new MeritBankController();
		CDOffering temp = new CDOffering(0, 0);
		assertNotNull(tempController.addCDOfferingByReq(temp));
	}

	@Test
	void testGetCDOfferingsByReq() {
		MeritBankController tempController = new MeritBankController();
		CDOffering temp = new CDOffering(0, 0);
		tempController.addCDOfferingByReq(temp);
		assertNotNull(tempController.getCDOfferingsByReq());
	}

}
