package com.meritamerica.assignment5.models;

public class ExceedsCombinedBalanceLimitException extends Exception {
	public ExceedsCombinedBalanceLimitException() {
        super("ExceedsCombinedBalanceLimitException");
    }
}
