package com.meritamerica.assignment5.models;

public class NegativeAmountException extends Exception {
	public NegativeAmountException() {
        super("NegativeAmountException");
    }
}
