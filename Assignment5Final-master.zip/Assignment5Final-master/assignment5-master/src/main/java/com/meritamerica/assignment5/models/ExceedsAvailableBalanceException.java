package com.meritamerica.assignment5.models;

public class ExceedsAvailableBalanceException extends Exception {
	public ExceedsAvailableBalanceException() {
        super("ExceedsAvailableBalanceException");
    }
}
