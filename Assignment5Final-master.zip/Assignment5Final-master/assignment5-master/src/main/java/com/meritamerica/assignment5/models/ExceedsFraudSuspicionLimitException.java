package com.meritamerica.assignment5.models;

public class ExceedsFraudSuspicionLimitException extends Exception {
	
	public ExceedsFraudSuspicionLimitException() {
        super("ExceedsFraudSuspicionLimitException");
    }
}
